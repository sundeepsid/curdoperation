package com.MDBBean;




import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.jboss.ejb3.annotation.ResourceAdapter;


@MessageDriven(name = "GetXmlListener", activationConfig = {

@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
@ActivationConfigProperty(propertyName = "destination", propertyValue = "${property.mq.consumer.etlqueue}"),
@ActivationConfigProperty(propertyName = "useJNDI", propertyValue = "true"),
@ActivationConfigProperty(propertyName = "channel", propertyValue = "${websphere.channel}"),
@ActivationConfigProperty(propertyName = "hostName", propertyValue = "${websphere.hostName}"),
@ActivationConfigProperty(propertyName = "queueManager", propertyValue = "message"),
@ActivationConfigProperty(propertyName = "port", propertyValue = "1412"),
@ActivationConfigProperty(propertyName ="queuename", propertyValue="decode"),
@ActivationConfigProperty(propertyName = "transportType", propertyValue = "${websphere.transportType}")
// @ActivationConfigProperty(propertyName = "username", propertyValue =
// "foo"),
// @ActivationConfigProperty(propertyName = "password", propertyValue =
// "bar")${websphere.port}${websphere.queueManager}
})
@ResourceAdapter(value = "${websphere.resource.adapter}")

public class MDBConsumer implements MessageListener {

   /**
    * Default constructor. 
    */
	
	 String EncodedMessage=null;
	 Class cls=null;
	 Object obj=null;
	 Method method=null;
   public MDBConsumer() {
       // TODO Auto-generated constructor stub
   }
    
    /**
    * @see MessageListener#onMessage(Message)
    */
   public void onMessage(Message message) {
       // TODO Auto-generated method stub
    
       
       TextMessage tm = (TextMessage) message;
       EncodedMessage=tm.toString();
       Class noparams[] = new Class[1];
       noparams[0]=String.class;
       
       
       
       
       
     	
       try {
         System.out.println("Received message "+EncodedMessage);
         System.out.println("Test");
       }
       catch(Exception e)
       {
    	   
       }
      try {
		cls = Class.forName("com.decode.ReflectionCalling");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       try {
		obj =cls.newInstance();
	} catch (InstantiationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      try {
		method =cls.getDeclaredMethod("reflections",noparams);
	} catch (NoSuchMethodException | SecurityException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        try {
			method.invoke(obj,new String("d"));
			/*JMSProducer1 jms=new JMSProducer1();
			jms.transformed("transformed.xml");*/
			
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
}

